# Curso **2808 - Fundamentos do Entity Framework**.

Conhecer fundamentos é essencial para qualquer desenvolvedor. Os fundamentos são os conceitos que servem como um alicerce, e permitirão que você aprenda novas tecnologias com mais facilidade, já que os conceitos fundamentais são compartilhados entre tecnologias diferentes.
